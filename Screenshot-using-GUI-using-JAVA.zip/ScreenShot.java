
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.image.BufferedImage;
import java.io.File;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ScreenShot extends JFrame {

	private JPanel contentPane;
	Robot robot;
	BufferedImage bufferedImage;
	JFileChooser fileChooser;
	String extension ="png";
	private JTextField inputFileName;
	private JLabel fileName, labelFormat;
	private JButton btnDelete;

	
	public static void main(String[] args) {
		
				try {
					ScreenShot frame = new ScreenShot();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
		
	}

	//Create the frame.
	 
	public ScreenShot() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 306, 164);
		setResizable(false);
		setAlwaysOnTop(true);
		setLocationRelativeTo(null);
		setTitle("Screen Shot");
		contentPane = new JPanel();
		contentPane.setForeground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		//adding labels and button
		addLabels();
		addBtnDelete();
		
		//getting the image name, default is screen-shot

		inputFileName = new JTextField();
		inputFileName.setText("screen-shot");
		inputFileName.setBounds(91, 9, 119, 20);
		contentPane.add(inputFileName);
		inputFileName.setColumns(10);

		//adding radio buttons for user to choose between png and jpg format

		JRadioButton formatOptionPNG = new JRadioButton("png");
		formatOptionPNG.setSelected(true);
		formatOptionPNG.setBounds(101, 42, 50, 23);
		contentPane.add(formatOptionPNG);

		JRadioButton formatOptionJPG = new JRadioButton("jpg");
		formatOptionJPG.setBounds(166, 42, 50, 23);
		contentPane.add(formatOptionJPG);

		//ButtonGroup help us so that only one button is selected at a time

		ButtonGroup buttonGroup = new ButtonGroup();
		buttonGroup.add(formatOptionPNG);
		buttonGroup.add(formatOptionJPG);

		JButton screenShot = new JButton("Screen Shot");
		screenShot.setBounds(80, 90, 154, 23);
		screenShot.addActionListener((e) -> {

			try {
				
				robot = new Robot();
				
				Rectangle rectangle = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
				
				this.setVisible(false);
				
				bufferedImage = robot.createScreenCapture(rectangle);
				this.setVisible(true);
				
				fileChooser = new JFileChooser();
				
				fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				
				if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
					if (formatOptionPNG.isSelected()) {
						
						extension = "jpg";
					}
					//get the location by
					String directory = fileChooser.getSelectedFile().getAbsolutePath().toString();
				
					ImageIO.write(bufferedImage, extension,
							new File(directory + "\\" + inputFileName.getText() + "." + extension));

				}
			} catch (Exception exception) {
				JOptionPane.showMessageDialog(null, "Error");
			}
			inputFileName.setText("screen-shot");

		});
		contentPane.setLayout(null);
		contentPane.add(screenShot);


		

	}

	private void addLabels() {

		labelFormat = new JLabel("Format  :");
		labelFormat.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		labelFormat.setBounds(10, 46, 80, 14);
		this.getContentPane().add(labelFormat);

		fileName = new JLabel("File Name :");
		fileName.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		fileName.setBounds(10, 11, 80, 14);
		contentPane.add(fileName);

	}
	
	private void addBtnDelete() {
		
		btnDelete = new JButton("Del");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inputFileName.setText("");
			}
		});
		btnDelete.setBounds(220, 8, 55, 23);
		this.getContentPane().add(btnDelete);
	}
	
}





 
